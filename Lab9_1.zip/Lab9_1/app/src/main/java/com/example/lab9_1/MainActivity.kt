package com.example.lab9_1

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.lab9_1.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    // 1. 使用 ViewBinding 取代 findViewById
    private lateinit var binding: ActivityMainBinding

    // 2. 用來追蹤賽跑狀態，方便隨時喊停
    private var isRacing = false

    // 定義參賽者的 Job (像是賽跑的合約，可以用來取消比賽)
    private var rabbitJob: Job? = null
    private var turtleJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 初始化 ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupWindowInsets()

        binding.btnStart.setOnClickListener {
            startRace()
        }
    }

    private fun startRace() {
        // --- 初始化比賽狀態 ---
        binding.btnStart.isEnabled = false
        binding.sbRabbit.progress = 0
        binding.sbTurtle.progress = 0
        isRacing = true

        // --- 兔子起跑 ---
        // launch: 啟動一個協程
        rabbitJob = lifecycleScope.launch {
            var progress = 0
            // 只要還在比賽且沒到終點，就繼續跑
            while (isRacing && progress < 100) {

                // 模擬兔子的隨機偷懶
                // delay 是協程專用的「暫停」，它不會卡死畫面，比 Thread.sleep 好
                delay(100)
                if ((0..2).random() < 2) { // 2/3 機率偷懶 (0, 1 會進來)
                    delay(300)
                }

                progress += 3

                // 直接更新 UI，不用 Handler！
                binding.sbRabbit.progress = progress

                // 判斷勝利
                checkWinner(progress, "兔子")
            }
        }

        // --- 烏龜起跑 ---
        turtleJob = lifecycleScope.launch {
            var progress = 0
            while (isRacing && progress < 100) {

                delay(100) // 烏龜穩定跑，不偷懶
                progress += 1

                binding.sbTurtle.progress = progress

                checkWinner(progress, "烏龜")
            }
        }
    }

    // 檢查勝利者
    private fun checkWinner(progress: Int, name: String) {
        // 如果已經有人贏了 (isRacing 被改成 false)，就不要再判斷了
        if (progress >= 100 && isRacing) {
            isRacing = false // 比賽結束

            // 取消另一位的比賽資格 (停止另一個協程)
            rabbitJob?.cancel()
            turtleJob?.cancel()

            showToast("$name 勝利")
            binding.btnStart.isEnabled = true
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}